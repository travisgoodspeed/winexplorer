**************************************************************************
*** This Version of WinExplorer will not run without installing the    ***
*** Microsoft Script Control.                                          ***
*** You MUST run the file sct10en.exe to install it.                   ***
**************************************************************************

The script control can be downloaded from:
    http://msdn.microsoft.com/scripting/scriptcontrol/x86/sct10en.exe

Important:

The Scripting Engines are for Windows 95, Windows 98 & Windows NT 4.0.

If you are running Windows 98 or Windows NT 4.0 you are home free.

If you are running Windows 95 and are getting the message "Script Error on Line 0"
or other errors when you try to run a VB or Java Script, you still need to install
some components.

Windows 95 users must have OSR2 installed or be running
Microsoft Internet Explorer 4.0 or later for these files to work properly.
Windows 95 users without Microsoft Internet Explorer 4.0 or OSR2 will need to
install DCOM before using these files.

If you are running Windows 95 & you feel that you MUST install this stuff piece by piece, 
instead of installing Microsoft Internet Explorer 5.0, you will need the following files:

  File                             DL Location                               Description
-------------------------------------------------------------------------------------------    
ste50en.exe    http://www.microsoft.com/msdownload/vbscript/scripting.asp   Version 5 VB & Java Runtimes
dcom95.exe     http://www.microsoft.com/com/dcom/dcom1_2/download.asp       Decom 95


**************************************************************************

  If you are having problems with button graphics not being visible,
  or other menu/button problems, the file you need to update is "comctl32.dll" 
  which is located in your windows\system dir. 

  The easiest fix is to install Microsoft Internet Explorer 5.x.

  If you are running windows 95, and don't want to install IE5,
  then this is the file you need:
      http://support.microsoft.com/download/support/mslfiles/COM32UPD.EXE

  For more info read:
      http://support.microsoft.com/support/kb/articles/Q165/4/87.asp

**************************************************************************
