This file has been DL'd from....

http://www.metaloid.com

For tech support come to....

http://www.atsdss.com

For card readers, unloopers, H cards etc come to..

http://www.cardcleaners.com/ and http://www.zenontech.com/